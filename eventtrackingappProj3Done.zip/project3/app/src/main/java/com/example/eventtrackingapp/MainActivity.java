package com.example.eventtrackingapp;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
public class MainActivity extends Activity {
    private DatabaseHelper databaseHelper;
    private EditText editTextUsername;
    private EditText editTextPassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showLoginScreen();
    }
    private void showLoginScreen() {
        setContentView(R.layout.activity_login);
        databaseHelper = new DatabaseHelper(this);
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonCreateAccount = findViewById(R.id.buttonCreateAccount);
        buttonLogin.setOnClickListener(v -> loginUser());
        buttonCreateAccount.setOnClickListener(v -> createNewUser());
    }
    private void loginUser() {
        String username = editTextUsername.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter a username and password.", Toast.LENGTH_SHORT).show();
            return;
        }
        int userId = databaseHelper.checkLogin(username, password);
        if (userId != -1) {
            openEventList(userId);
        } else {
            Toast.makeText(this, "Invalid login. Create an account if you are a new user.", Toast.LENGTH_SHORT).show();
        }
    }
    private void createNewUser() {
        String username = editTextUsername.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Username and password are required.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (databaseHelper.usernameExists(username)) {
            Toast.makeText(this, "That username already exists.", Toast.LENGTH_SHORT).show();
            return;
        }
        long result = databaseHelper.createUser(username, password, "");
        if (result != -1) {
            Toast.makeText(this, "Account created successfully.", Toast.LENGTH_SHORT).show();
            openEventList((int) result);
        } else {
            Toast.makeText(this, "Account could not be created.", Toast.LENGTH_SHORT).show();
        }
    }
    private void openEventList(int userId) {
        Intent intent = new Intent(this, EventListActivity.class);
        intent.putExtra("USER_ID", userId);
        startActivity(intent);
    }
}