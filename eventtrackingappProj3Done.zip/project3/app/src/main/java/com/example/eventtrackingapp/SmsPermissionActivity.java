package com.example.eventtrackingapp;
import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
public class SmsPermissionActivity extends Activity {
    private static final int SMS_PERMISSION_REQUEST_CODE = 100;
    private DatabaseHelper databaseHelper;
    private int currentUserId;
    private EditText editTextSmsPhone;
    private TextView textViewSmsStatus;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);
        databaseHelper = new DatabaseHelper(this);
        currentUserId = getIntent().getIntExtra("USER_ID", -1);
        textViewSmsStatus = findTextViewByName("textViewSmsStatus");
        editTextSmsPhone = findEditTextByName("editTextSmsPhone");
        if (editTextSmsPhone != null && currentUserId != -1) {
            editTextSmsPhone.setText(databaseHelper.getUserPhone(currentUserId));
        }
        Button buttonSavePhone = findButtonByName("buttonSavePhone");
        Button buttonAllowSms = findFirstButtonByName("buttonRequestSmsPermission", "buttonAllowSms");
        Button buttonContinueWithoutSms = findButtonByName("buttonContinueWithoutSms");
        Button buttonBackToEvents = findButtonByName("buttonBackToEvents");
        if (buttonSavePhone != null) {
            buttonSavePhone.setOnClickListener(v -> savePhoneNumber());
        }
        if (buttonAllowSms != null) {
            buttonAllowSms.setOnClickListener(v -> requestSmsPermission());
        }
        if (buttonContinueWithoutSms != null) {
            buttonContinueWithoutSms.setOnClickListener(v -> {
                setStatusText("SMS reminders are turned off. The app will still work without SMS notifications.");
                finish();
            });
        }
        if (buttonBackToEvents != null) {
            buttonBackToEvents.setOnClickListener(v -> finish());
        }
        updatePermissionStatusText();
    }
    private void savePhoneNumber() {
        if (editTextSmsPhone == null) {
            Toast.makeText(this, "No phone number field was found on this screen.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (currentUserId == -1) {
            Toast.makeText(this, "User was not found.", Toast.LENGTH_SHORT).show();
            return;
        }
        String phone = editTextSmsPhone.getText().toString().trim();
        databaseHelper.updateUserPhone(currentUserId, phone);
        Toast.makeText(this, "Phone number saved.", Toast.LENGTH_SHORT).show();
    }
    private void requestSmsPermission() {
        if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            setStatusText("SMS permission is already granted. Event reminders can be sent.");
        } else {
            requestPermissions(
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE
            );
        }
    }
    private void updatePermissionStatusText() {
        if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            setStatusText("SMS permission is granted. Event reminders can be sent.");
        } else {
            setStatusText("SMS permission is not granted. The app will still work without SMS reminders.");
        }
    }
    private void setStatusText(String message) {
        if (textViewSmsStatus != null) {
            textViewSmsStatus.setText(message);
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                setStatusText("SMS permission granted. Event reminders can be sent.");
            } else {
                setStatusText("SMS permission denied. The app will still work without SMS reminders.");
            }
        }
    }
    private Button findButtonByName(String idName) {
        int id = getResources().getIdentifier(idName, "id", getPackageName());
        if (id == 0) {
            return null;
        }
        return findViewById(id);
    }
    private Button findFirstButtonByName(String firstIdName, String secondIdName) {
        Button firstButton = findButtonByName(firstIdName);
        if (firstButton != null) {
            return firstButton;
        }
        return findButtonByName(secondIdName);
    }
    private TextView findTextViewByName(String idName) {
        int id = getResources().getIdentifier(idName, "id", getPackageName());
        if (id == 0) {
            return null;
        }
        return findViewById(id);
    }
    private EditText findEditTextByName(String idName) {
        int id = getResources().getIdentifier(idName, "id", getPackageName());
        if (id == 0) {
            return null;
        }
        return findViewById(id);
    }
}