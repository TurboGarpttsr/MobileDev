package com.example.eventtrackingapp;
import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Typeface;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Gravity;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
public class EventListActivity extends Activity {
    private DatabaseHelper databaseHelper;
    private TableLayout tableEvents;
    private int currentUserId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);
        databaseHelper = new DatabaseHelper(this);
        currentUserId = getIntent().getIntExtra("USER_ID", -1);
        tableEvents = findViewById(R.id.tableEvents);
        Button buttonAddEvent = findViewById(R.id.buttonAddEvent);
        Button buttonSmsSettings = findViewById(R.id.buttonSmsSettings);
        buttonAddEvent.setOnClickListener(v -> openAddEventScreen());
        buttonSmsSettings.setOnClickListener(v -> openSmsSettingsScreen());
        refreshEventsTable();
        sendTodayEventAlerts();
    }
    @Override
    protected void onResume() {
        super.onResume();
        refreshEventsTable();
        sendTodayEventAlerts();
    }
    private void openAddEventScreen() {
        Intent intent = new Intent(this, AddEditEventActivity.class);
        intent.putExtra("USER_ID", currentUserId);
        startActivity(intent);
    }
    private void openSmsSettingsScreen() {
        Intent intent = new Intent(this, SmsPermissionActivity.class);
        intent.putExtra("USER_ID", currentUserId);
        startActivity(intent);
    }
    private void refreshEventsTable() {
        tableEvents.removeAllViews();
        addHeaderRow();
        Cursor cursor = databaseHelper.getEventsForUser(currentUserId);
        if (cursor.getCount() == 0) {
            addEmptyRow();
            cursor.close();
            return;
        }
        while (cursor.moveToNext()) {
            int eventId = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_ID));
            String title = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_TITLE));
            String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_DATE));
            String time = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_TIME));
            addEventRow(eventId, title, date, time);
        }
        cursor.close();
    }
    private void addHeaderRow() {
        TableRow row = new TableRow(this);
        row.addView(makeTextView("Event", true));
        row.addView(makeTextView("Date", true));
        row.addView(makeTextView("Time", true));
        row.addView(makeTextView("Edit", true));
        row.addView(makeTextView("Delete", true));
        tableEvents.addView(row);
    }
    private void addEmptyRow() {
        TableRow row = new TableRow(this);
        TextView emptyText = makeTextView("No events added yet.", false);
        row.addView(emptyText);
        tableEvents.addView(row);
    }
    private void addEventRow(int eventId, String title, String date, String time) {
        TableRow row = new TableRow(this);
        row.addView(makeTextView(title, false));
        row.addView(makeTextView(date, false));
        row.addView(makeTextView(time, false));
        Button editButton = new Button(this);
        editButton.setText("Edit");
        editButton.setOnClickListener(v -> openEditEventScreen(eventId));
        Button deleteButton = new Button(this);
        deleteButton.setText("Delete");
        deleteButton.setOnClickListener(v -> {
            databaseHelper.deleteEvent(eventId);
            Toast.makeText(this, "Event deleted.", Toast.LENGTH_SHORT).show();
            refreshEventsTable();
        });
        row.addView(editButton);
        row.addView(deleteButton);
        tableEvents.addView(row);
    }
    private void openEditEventScreen(int eventId) {
        Intent intent = new Intent(this, AddEditEventActivity.class);
        intent.putExtra("USER_ID", currentUserId);
        intent.putExtra("EVENT_ID", eventId);
        startActivity(intent);
    }
    private TextView makeTextView(String text, boolean bold) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setPadding(8, 8, 8, 8);
        textView.setGravity(Gravity.CENTER);
        if (bold) {
            textView.setTypeface(null, Typeface.BOLD);
        }
        return textView;
    }
    private void sendTodayEventAlerts() {
        if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        String phone = databaseHelper.getUserPhone(currentUserId);
        if (phone == null || phone.trim().isEmpty()) {
            return;
        }
        String todayDate = new SimpleDateFormat("MM/dd/yyyy", Locale.US).format(new Date());
        Cursor cursor = databaseHelper.getUnsentEventsForToday(currentUserId, todayDate);
        while (cursor.moveToNext()) {
            int eventId = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_ID));
            String title = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_TITLE));
            String time = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_TIME));
            String message = "Event reminder: " + title + " is scheduled today at " + time + ".";
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phone, null, message, null, null);
                databaseHelper.markEventSmsSent(eventId);
                Toast.makeText(this, "SMS reminder sent for " + title, Toast.LENGTH_SHORT).show();
            } catch (Exception exception) {
                Toast.makeText(this, "SMS could not be sent.", Toast.LENGTH_SHORT).show();
            }
        }
        cursor.close();
    }
}