package com.example.eventtrackingapp;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "event_tracker.db";
    private static final int DATABASE_VERSION = 1;
    public static final String TABLE_USERS = "users";
    public static final String USER_ID = "id";
    public static final String USERNAME = "username";
    public static final String PASSWORD = "password";
    public static final String PHONE = "phone";
    public static final String TABLE_EVENTS = "events";
    public static final String EVENT_ID = "id";
    public static final String EVENT_USER_ID = "user_id";
    public static final String EVENT_TITLE = "title";
    public static final String EVENT_DATE = "date";
    public static final String EVENT_TIME = "time";
    public static final String EVENT_LOCATION = "location";
    public static final String EVENT_DETAILS = "details";
    public static final String EVENT_SMS_SENT = "sms_sent";
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                USERNAME + " TEXT UNIQUE NOT NULL, " +
                PASSWORD + " TEXT NOT NULL, " +
                PHONE + " TEXT)";
        String createEventsTable = "CREATE TABLE " + TABLE_EVENTS + " (" +
                EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                EVENT_USER_ID + " INTEGER NOT NULL, " +
                EVENT_TITLE + " TEXT NOT NULL, " +
                EVENT_DATE + " TEXT NOT NULL, " +
                EVENT_TIME + " TEXT NOT NULL, " +
                EVENT_LOCATION + " TEXT, " +
                EVENT_DETAILS + " TEXT, " +
                EVENT_SMS_SENT + " INTEGER DEFAULT 0)";
        db.execSQL(createUsersTable);
        db.execSQL(createEventsTable);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }
    public long createUser(String username, String password, String phone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(USERNAME, username);
        values.put(PASSWORD, password);
        values.put(PHONE, phone);
        return db.insert(TABLE_USERS, null, values);
    }
    public int checkLogin(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{USER_ID},
                USERNAME + "=? AND " + PASSWORD + "=?",
                new String[]{username, password},
                null,
                null,
                null
        );
        int userId = -1;
        if (cursor.moveToFirst()) {
            userId = cursor.getInt(0);
        }
        cursor.close();
        return userId;
    }
    public boolean usernameExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{USER_ID},
                USERNAME + "=?",
                new String[]{username},
                null,
                null,
                null
        );
        boolean exists = cursor.moveToFirst();
        cursor.close();
        return exists;
    }
    public String getUserPhone(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{PHONE},
                USER_ID + "=?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                null
        );
        String phone = "";
        if (cursor.moveToFirst()) {
            phone = cursor.getString(0);
        }
        cursor.close();
        if (phone == null) {
            return "";
        }
        return phone;
    }
    public void updateUserPhone(int userId, String phone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(PHONE, phone);
        db.update(
                TABLE_USERS,
                values,
                USER_ID + "=?",
                new String[]{String.valueOf(userId)}
        );
    }
    public long addEvent(int userId, String title, String date, String time, String location, String details) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(EVENT_USER_ID, userId);
        values.put(EVENT_TITLE, title);
        values.put(EVENT_DATE, date);
        values.put(EVENT_TIME, time);
        values.put(EVENT_LOCATION, location);
        values.put(EVENT_DETAILS, details);
        values.put(EVENT_SMS_SENT, 0);
        return db.insert(TABLE_EVENTS, null, values);
    }
    public Cursor getEventsForUser(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(
                TABLE_EVENTS,
                null,
                EVENT_USER_ID + "=?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                EVENT_DATE + " ASC"
        );
    }
    public Cursor getEventById(int eventId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(
                TABLE_EVENTS,
                null,
                EVENT_ID + "=?",
                new String[]{String.valueOf(eventId)},
                null,
                null,
                null
        );
    }
    public int updateEvent(int eventId, String title, String date, String time, String location, String details) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(EVENT_TITLE, title);
        values.put(EVENT_DATE, date);
        values.put(EVENT_TIME, time);
        values.put(EVENT_LOCATION, location);
        values.put(EVENT_DETAILS, details);
        values.put(EVENT_SMS_SENT, 0);
        return db.update(
                TABLE_EVENTS,
                values,
                EVENT_ID + "=?",
                new String[]{String.valueOf(eventId)}
        );
    }
    public void deleteEvent(int eventId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(
                TABLE_EVENTS,
                EVENT_ID + "=?",
                new String[]{String.valueOf(eventId)}
        );
    }
    public Cursor getUnsentEventsForToday(int userId, String todayDate) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(
                TABLE_EVENTS,
                null,
                EVENT_USER_ID + "=? AND " + EVENT_DATE + "=? AND " + EVENT_SMS_SENT + "=0",
                new String[]{String.valueOf(userId), todayDate},
                null,
                null,
                EVENT_TIME + " ASC"
        );
    }
    public void markEventSmsSent(int eventId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(EVENT_SMS_SENT, 1);
        db.update(
                TABLE_EVENTS,
                values,
                EVENT_ID + "=?",
                new String[]{String.valueOf(eventId)}
        );
    }
}