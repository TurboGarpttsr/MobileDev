package com.example.eventtrackingapp;
import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
public class AddEditEventActivity extends Activity {
    private DatabaseHelper databaseHelper;
    private EditText editTextEventName;
    private EditText editTextEventDate;
    private EditText editTextEventTime;
    private EditText editTextEventLocation;
    private EditText editTextEventDetails;
    private int currentUserId;
    private int currentEventId = -1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);
        databaseHelper = new DatabaseHelper(this);
        currentUserId = getIntent().getIntExtra("USER_ID", -1);
        currentEventId = getIntent().getIntExtra("EVENT_ID", -1);
        editTextEventName = findViewById(R.id.editTextEventName);
        editTextEventDate = findViewById(R.id.editTextEventDate);
        editTextEventTime = findViewById(R.id.editTextEventTime);
        editTextEventLocation = findViewById(R.id.editTextEventLocation);
        editTextEventDetails = findViewById(R.id.editTextEventDetails);
        Button buttonSaveEvent = findViewById(R.id.buttonSaveEvent);
        Button buttonCancelEvent = findViewById(R.id.buttonCancelEvent);
        if (currentEventId != -1) {
            loadEventForEditing();
        }
        buttonSaveEvent.setOnClickListener(v -> saveEvent());
        buttonCancelEvent.setOnClickListener(v -> finish());
    }
    private void loadEventForEditing() {
        Cursor cursor = databaseHelper.getEventById(currentEventId);
        if (cursor.moveToFirst()) {
            editTextEventName.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_TITLE)));
            editTextEventDate.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_DATE)));
            editTextEventTime.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_TIME)));
            editTextEventLocation.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_LOCATION)));
            editTextEventDetails.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.EVENT_DETAILS)));
        }
        cursor.close();
    }
    private void saveEvent() {
        String eventName = editTextEventName.getText().toString().trim();
        String eventDate = editTextEventDate.getText().toString().trim();
        String eventTime = editTextEventTime.getText().toString().trim();
        String eventLocation = editTextEventLocation.getText().toString().trim();
        String eventDetails = editTextEventDetails.getText().toString().trim();
        if (eventName.isEmpty() || eventDate.isEmpty() || eventTime.isEmpty()) {
            Toast.makeText(this, "Event name, date, and time are required.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (currentEventId == -1) {
            databaseHelper.addEvent(
                    currentUserId,
                    eventName,
                    eventDate,
                    eventTime,
                    eventLocation,
                    eventDetails
            );
            Toast.makeText(this, "Event added.", Toast.LENGTH_SHORT).show();
        } else {
            databaseHelper.updateEvent(
                    currentEventId,
                    eventName,
                    eventDate,
                    eventTime,
                    eventLocation,
                    eventDetails
            );
            Toast.makeText(this, "Event updated.", Toast.LENGTH_SHORT).show();
        }
        finish();
    }
}